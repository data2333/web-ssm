CREATE FUNCTION count_born_in_year(p_year INT)
  RETURNS INT
  BEGIN
    RETURN (SELECT COUNT(*) FROM student WHERE year(sbirth)=p_year);
  END;
